# turntable

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```
### Note
```

在remix中部署好合约，在views/home.vue添加修改 "crowdfundingContract:" 为部署的合约地址
需安装ganache 
需安装chrome插件metamask
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).

