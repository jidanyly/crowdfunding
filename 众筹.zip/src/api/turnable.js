import Web3 from "web3";



const setName = async () =>{


    console.log(setName);
}